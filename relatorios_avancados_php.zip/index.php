<?php
require 'conexao.php';

$curso = $_GET['curso'] ?? '';
$mediaMin = $_GET['media'] ?? '';

$sql = "SELECT * FROM alunos WHERE 1=1";
$params = [];

if (!empty($curso)) {
    $sql .= " AND curso = :curso";
    $params[':curso'] = $curso;
}

if (!empty($mediaMin)) {
    $sql .= " AND media_final >= :media";
    $params[':media'] = $mediaMin;
}

$sql .= " ORDER BY media_final DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$alunos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relatório Avançado</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
        th { background-color: #4CAF50; color: white; }
    </style>
</head>
<body>
    <h1>Relatório Avançado de Alunos</h1>
    <form method="GET">
        Curso:
        <select name="curso">
            <option value="">Todos</option>
            <option value="Informática" <?= $curso == 'Informática' ? 'selected' : '' ?>>Informática</option>
            <option value="Redes" <?= $curso == 'Redes' ? 'selected' : '' ?>>Redes</option>
        </select>
        Média mínima:
        <input type="number" step="0.1" name="media" value="<?= htmlspecialchars($mediaMin) ?>">
        <button type="submit">Filtrar</button>
    </form>

    <table>
        <tr>
            <th>ID</th><th>Nome</th><th>Curso</th><th>Média Final</th><th>Data Registro</th>
        </tr>
        <?php foreach ($alunos as $a): ?>
        <tr>
            <td><?= $a['id'] ?></td>
            <td><?= htmlspecialchars($a['nome']) ?></td>
            <td><?= htmlspecialchars($a['curso']) ?></td>
            <td><?= number_format($a['media_final'], 1, ',', '.') ?></td>
            <td><?= date('d/m/Y', strtotime($a['data_registro'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <a href="exportar_pdf.php?curso=<?= urlencode($curso) ?>&media=<?= urlencode($mediaMin) ?>">Exportar PDF</a>
</body>
</html>