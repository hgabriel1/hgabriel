<?php
require 'conexao.php';
require 'vendor/autoload.php';

use Dompdf\Dompdf;

$curso = $_GET['curso'] ?? '';
$mediaMin = $_GET['media'] ?? '';

$sql = "SELECT * FROM alunos WHERE 1=1";
$params = [];

if (!empty($curso)) {
    $sql .= " AND curso = :curso";
    $params[':curso'] = $curso;
}

if (!empty($mediaMin)) {
    $sql .= " AND media_final >= :media";
    $params[':media'] = $mediaMin;
}

$sql .= " ORDER BY media_final DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$alunos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$html = "<h2>Relatório de Alunos</h2>
<table border='1' width='100%' style='border-collapse:collapse;'>
<tr>
<th>ID</th><th>Nome</th><th>Curso</th><th>Média Final</th><th>Data</th>
</tr>";
foreach ($alunos as $a) {
    $html .= "<tr>
        <td>{$a['id']}</td>
        <td>{$a['nome']}</td>
        <td>{$a['curso']}</td>
        <td>{$a['media_final']}</td>
        <td>".date('d/m/Y', strtotime($a['data_registro']))."</td>
    </tr>";
}
$html .= "</table>";

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("relatorio.pdf", ["Attachment" => false]);
?>